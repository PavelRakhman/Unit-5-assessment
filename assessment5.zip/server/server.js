
const dbDATA = require('../config/db-config')
require('dotenv').config()
let dbPassword = process.env.password
const express = require('express')
const cors = require('cors')
const app = express()
app.use(express.json())
app.use(cors())

const Sequelize = require('sequelize')
const { all } = require('axios')
const { DataTypes } = Sequelize
const ORMInstance = new Sequelize(dbDATA.database, dbDATA.user, dbPassword, {
host: dbDATA.host,
port: dbDATA.port,
dialect:'mysql'
})



ORMInstance.authenticate()
.then(()=>{console.log('Connected to the database successfully')})
.catch((error)=>{console.log('Error connecting to the database')})

//creation of the new table called cities

let Model = ORMInstance.define('cities',{

    city_id:{type: DataTypes.INTEGER, primaryKey:true, allowNull:false, autoIncrement:true},
    city_name:{type: DataTypes.STRING, allowNull:false},
    city_rating:{type: DataTypes.STRING, allowNull:false, defaultValue:0}
},{freezeTableName:true, timeStamps:false})

Model.sync({alter:true})
.then((data)=>{console.log('Synchronization successful')})
.catch((error)=>{console.log(error)})







app.post('/api/addcity', (req, res)=>{
    let cityDataObject = Object.assign({}, req.body)
    let cityName = cityDataObject.city
let cityRating = cityDataObject.rating
res.status(200).send(cityName)   


Model.sync({alter:true})
.then(()=>{
let newcity = Model.build({city_name:cityName, city_rating:cityRating})
newcity.save()



})
.catch((error)=>{console.log('Error syncing with the database')})
})


app.get('/api/getcity', (req, res)=>{
    let dataArray = []
    let cityName = req.query.city
    Model.sync()
    .then(()=>{
        return Model.findAll({attributes:['city_name', 'city_rating'], where: {city_name: cityName}})
        .then((data)=>{
            data.forEach(element => {
                dataArray.push(element.toJSON())
                console.log(dataArray)
                res.status(200).send(dataArray)
            
            });
            
            
        })


    })

    .catch((error)=>{console.log(error)})
})


app.listen(3500, ()=>{console.log('Server started')})