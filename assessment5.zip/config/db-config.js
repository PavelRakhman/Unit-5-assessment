let database = 'testapp'
let user = 'prwdev'
let host = 'test.c2v1o5gvmivs.us-east-2.rds.amazonaws.com'
let port = 3306

const dbData={
    database, user, host, port
}
module.exports=dbData

