


/*elements for the first type of request(sending city
 data to the server and adding the city to the database)*/
 const AddCityFormEl = document.querySelector(".AddCityForm")
const responseAreaOne = document.querySelector(".submitResponse-1")
const responseAreaTwo = document.querySelector(".submitResponse-2")

 /*elements for the second type of request(requesting all data from the database)*/
 const getCityDataForm = document.querySelector(".getCityDataForm")

 let cityDataTable = document.querySelector(".CityDataTable")
 
 
 
function formtoObject(form) //this function converts all values from the form inputs into a javascript object
{
    const fd = new FormData(form)
    const formDataObject = Object.fromEntries(fd)
    return formDataObject
}

//when the user clicks the 'submit button, values form the inputs are converted into an object and sent to the sserver'



async function addCity(cityObject)
{
    try{
        responseAreaOne.innerHTML=null
        responseAreaOne.style.display = "none"
let response = await axios.post('http://localhost:3500/api/addcity', cityObject)
console.log(response.data)
responseAreaOne.innerHTML = 'City information sent to the server and added to the database'
responseAreaOne.style.display ="flex"
    }
    
    catch(error){
responseAreaOne.innerHTML = error.message;
responseAreaOne.style.display = "flex"
console.log(error)
    }
}

async function getCityData(cityName)
{
    responseAreaTwo.style.display = "none"
    responseAreaTwo.innerHTML=null
    try
    {
let response = await axios.get(`http://localhost:3500/api/getcity?city=${cityName}`)

let dataArray = response.data
dataArray.forEach(element=>{
    let cityName = element.city_name
    let cityRating = element.city_rating
    console.log(`The name of the city is ${cityName}. The rating of the city is ${cityRating}.`)
    let tr = document.createElement('tr')
    let td1 = document.createElement('td')
    let td2 = document.createElement('td')
    let txt = document.createTextNode(cityName)
    let txt2 = document.createTextNode(cityRating)
    td1.appendChild(txt)
    td2.appendChild(txt2)
    tr.appendChild(td1)
    tr.appendChild(td2)
    cityDataTable.appendChild(tr)
    td1.style.color = "#fff"
    td2.style.color = "#fff"


})

    }
    catch(error)
    {
        responseAreaTwo.innerHTML = error
        responseAreaTwo.style.display = "flex"
console.log(error)
    }
}



AddCityFormEl.addEventListener("submit", (event)=>{
    event.preventDefault()
    responseAreaOne.innerHTML = null
    const formDataObject = formtoObject(AddCityFormEl)
console.log(formDataObject)
addCity(formDataObject)
})

//the code below is for the second type of request--that is, fetching informationon all cities stored in the database

getCityDataForm.addEventListener("submit", (event)=>{
event.preventDefault()
    const cityObject = formtoObject(getCityDataForm)
    const cityName = cityObject.city
    getCityData(cityName)

})