const port = 4000
const http = require("http")
const cors = require("cors")
require("dotenv").config()
const app = require("./app")
const server = http.createServer(app)

server.listen(port, () => {console.log(`Server listening on ${port}`)})