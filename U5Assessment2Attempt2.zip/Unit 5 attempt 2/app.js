const express = require("express")
const cors = require("cors")
const app = express()
app.use(express.json())
app.use(cors())
const countriesRtr = require("./routes/countriesRtr")
let capitalRtr = require("./routes/capitalRtr")
let entryRtr = require("./routes/entry")
app.use("/api/countries",countriesRtr)
app.use("/api/capital", capitalRtr)
app.use("/api/entry", entryRtr)

module.exports = app