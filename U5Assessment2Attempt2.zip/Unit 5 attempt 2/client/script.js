//Forms
let addFormEl = document.querySelector(".AddEntryForm")
let getFormEl = document.querySelector(".GetEntryForm")

//Table that will display information received from the database
let TableEl = document.querySelector(".EntryTable")
{

}

//Select menus
let countrySelectEl = document.querySelector(".countrySelectMenu")
let capitalSelectEl = document.querySelector(".capitalSelectMenu")
let countrySelectElCol2 = document.querySelector(".countrySelectMenuCol2")
let capitalSelectElCol2 = document.querySelector(".capitalSelectMenuCol2")

let countryList = []//the array will store 




//A function that stores all data from a form in a java script object
function formToObject(formElement)
{
    let fd = new FormData(formElement)
    let result = Object.fromEntries(fd)
    return result
}

/* A function that takes in an array of strings(country names), creates <option>-elements and appends those elements to
a select menu
Parameters: array of strings and a select menu element*/
//Axios requests




//Axios requests

async function addEntry(Obj)
{
    try
    {
        let response = await axios.post("http://localhost:4000/api/entry/new",Obj)
        console.log(response.data)
    }

    catch
    {
console.log("Failed to add an entry")
    }
}


async function getCapital(countryName)
{
    try
    {
capitalSelectEl.innerHTML = null
        let response = await axios.get(`http://localhost:4000/api/capital?cn=${countryName}`)
let capital = response.data
const text = document.createTextNode(capital.name)
const optn = document.createElement("option")
optn.append(text)
capitalSelectEl.appendChild(optn)
// const txt = document.createTextNode(capital)
// let optn = document.createElement("option")
// optn.appendChild(txt)
// capitalSelectEl.appendChild(optn)
    }
    
    catch
    {
console.log("Failed to get the capital")
    }
}

async function getCapitalForm2(countryName)
{

    try
    {
        capitalSelectElCol2.innerHTML = null
        let response = await axios.get(`http://localhost:4000/api/capital?cn=${countryName}`)
        let capital = response.data
        const text = document.createTextNode(capital.name)
        const optn = document.createElement("option")
        optn.append(text)
        capitalSelectElCol2.appendChild(optn)
    }


    catch{
        console.timeLog("Failed to get the country")
    }
}


// A function that gets all entries for the selected city

function displayEntries(A)
{
A.forEach(element=>{
    const tr = document.createElement("tr")
    const td1 = document.createElement("td")
    const td2 = document.createElement("td")
    const td3 = document.createElement("td")
    const td4 = document.createElement("td")
    const capitalName = element.capital
    const countryName = element.countryName
       const capitalRating = element.rating
       const dateVisited = element.dateVisited
    td1.append(countryName)
    td2.append(capitalName)
    td3.append(dateVisited)
    td4.append(capitalRating)
    
    tr.appendChild(td1)
    tr.appendChild(td2)
    tr.appendChild(td3)
    tr.appendChild(td4)
    TableEl.appendChild(tr)
})
}

async function getEntry(cityName)
{
    try
    {
        
let response = await axios.get(`http://localhost:4000/api/entry/get?cptlname=${cityName}`)
let entries = response.data

displayEntries(entries)

    }

    catch
    {
        console.log("Failed to complete the request")}
}












//Event handlers

async function getCountries()
{
    try{
        countrySelectEl.innerHTML = null
countrySelectElCol2.innerHTML = null
        let response = await axios.get("http://localhost:4000/api/countries")
        let allCountries = response.data
        countryList = allCountries
countryList.forEach(element => {
    //this is where we append names of all countries to the select menus
    const txt = document.createTextNode(element)
    const optn = document.createElement("option")
    const txt2 = document.createTextNode(element)
    const optn2 = document.createElement("option")
    optn2.appendChild(txt2)
    countrySelectElCol2.appendChild(optn2)

    optn.appendChild(txt)
    countrySelectEl.appendChild(optn)
    
});
        
    }
    catch{ console.log("Failed to complete the request")}
}


window.addEventListener("load", (e)=>{
    e.preventDefault()

    TableEl.innerHTML = `<tr>
    <th>country</th>
    <th>capital name</th>
    <th>Date Visited</th>
    <th>rating</th>

    
    </tr>
    <tr>
        
    </tr>`
  getCountries()
})

/*When the user picks a country, a request is sent to the server. The 
server gets the capital from the database and sends it the front end */
countrySelectEl.addEventListener("click", function(e)
{
    e.preventDefault()
    let country = e.target.value
    capitalSelectEl.removeAttribute("disabled")
    getCapital(country)
    
    
}
)

countrySelectElCol2.addEventListener("click", function(e)
{
    e.preventDefault()
    let country = e.target.value
    getCapitalForm2(country)
   capitalSelectElCol2.removeAttribute("disabled")
    
    
}
)




addFormEl.addEventListener("submit", function(e)
{
e.preventDefault()
const newEntryObject = formToObject(addFormEl)
console.log(newEntryObject)
addEntry(newEntryObject)
})



getFormEl.addEventListener("submit", (e)=>{
    e.preventDefault()
const getEntryObject = formToObject(getFormEl)

getEntry(getEntryObject.capital)
})