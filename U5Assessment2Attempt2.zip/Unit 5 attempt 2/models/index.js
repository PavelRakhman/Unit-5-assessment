
'use strict';


const fs = require('fs');
const path = require('path');
const Sequelize = require('sequelize');
const process = require('process');
require("dotenv").config()
const capitals = require('./capitals');
const basename = path.basename(__filename);
const env = process.env.NODE_ENV || 'development';
const config = require(__dirname + '/../config/config.json')[env];
const db = {};

let allCapitals = require('../dataArrays/capitalList')
let allCountries = require('../dataArrays/countryList');
const { loadavg } = require('os');

let sequelize;
if (config.use_env_variable) {
  sequelize = new Sequelize(process.env[config.use_env_variable], config);
} else {
  sequelize = new Sequelize(config.database, config.username, config.password, config);
}

fs
  .readdirSync(__dirname)
  .filter(file => {
    return (
      file.indexOf('.') !== 0 &&
      file !== basename &&
      file.slice(-3) === '.js' &&
      file.indexOf('.test.js') === -1
    );
  })
  .forEach(file => {
    const model = require(path.join(__dirname, file))(sequelize, Sequelize.DataTypes);
    db[model.name] = model;
  });

Object.keys(db).forEach(modelName => {
  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
});

db.sequelize = sequelize;
db.Sequelize = Sequelize;

module.exports = db;

let Capital = db.capitals
let Country = db.countries
Capital.belongsTo(Country)
Country.hasOne(Capital)


//  sequelize.drop()
// .then(()=>{console.log('Connected to the database successfully')})
// .catch((error)=>{console.log(error)})

// sequelize.sync(()=>{console.log('Synced successfully')})
// .then()
// .catch((error)=>{console.log(error)})

async function CapitalToCountry(capitalNames, countryNames, index)
{
  let cptl, cntry
  cptl = await Capital.findOne({where:{name:capitalNames[index]}})
  cntry = await Country.findOne({where:{name:countryNames[index]}})
  cntry.setCapital(cptl)
}

sequelize.sync({alter:true})
.then(()=>{
  for (let i=0; i<allCapitals.length; i++)
  {CapitalToCountry(allCapitals, allCountries, i)}
})
.catch((error)=>{console.log(error)})

