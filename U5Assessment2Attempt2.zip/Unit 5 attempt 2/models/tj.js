'use strict'

module.exports =(sequelize, DataTypes)=> {
return sequelize.define("tj",
{
countryName: {type:DataTypes.STRING, allowNull:true, required:true, isAlphanumeric:true},
capital: {type:DataTypes.STRING, allowNull:true, required:true, isAlphanumeric:true},
rating:{type: DataTypes.INTEGER, allowNull:true, required:true},
dateVisited:{type: DataTypes.DATE}
},{freezeTableName:true, timeStamps: false, autoIncrement:true})    
}