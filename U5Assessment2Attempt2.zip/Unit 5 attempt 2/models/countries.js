'use strict'

module.exports =(sequelize, DataTypes)=>{
    return sequelize.define('countries',{
name:{type:DataTypes.STRING, allowNull:true, required:true, isAlphanumeric:true}
    }, {freezeTableName:true, timeStamps: false, autoIncrement:true})
}