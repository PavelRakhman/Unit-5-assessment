'use strict'

module.exports =(sequelize, DataTypes)=>{
    return sequelize.define('capitals',{

name:{type:DataTypes.STRING, allowNull:true, required:true, isAlphanumeric:true},
rating: {type: DataTypes.INTEGER, allowNull:true, required:true}
    }, {freezeTableName:true, timeStamps: false})
}