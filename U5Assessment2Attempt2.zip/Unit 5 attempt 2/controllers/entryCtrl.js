let models = require("../models")
let TJ = models.tj

function addEntry(req, res)
{
const newEntry = TJ.create({
    countryName: req.body.country,
    capital:req.body.capital,
    rating: req.body.rating,
    dateVisited: req.body.visited
})

res.status(200).send('New entry added')

}

function getAllEntries(req,res)
{
    let capitalName = req.query.cptlname

    return TJ.findAll({where:{capital:capitalName}})
    .then((data)=>{
        console.log(data)
        res.status(200).send(data)
    }).catch((error)=>{console.log(error)})
        
    
}


module.exports = {addEntry:addEntry, getAllEntries: getAllEntries}