let models = require("../models")
let cntrs = models.countries
let countryNames =[]
let allCountries = []
function sendAllCountries(req,res)
{
return cntrs.findAll()
.then((data)=>{
    allCountries = JSON.parse(JSON.stringify(data))
    allCountries.forEach(element => {
        countryNames.push(element.name)
})
res.status(200).send(countryNames)
})
.catch((error)=>{console.log(error)})

}


module.exports = {sendAllCountries:sendAllCountries}