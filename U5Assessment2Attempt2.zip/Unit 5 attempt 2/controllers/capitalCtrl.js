let models = require('../models')
let cptls = models.capitals
let cntrs = models.countries

function sendCapital(req,res)
{
    let country
    let cntryName = req.query.cn
return cntrs.findOne({where:{name:cntryName}})
.then((data)=>{
    country = data
    return country.getCapital()
    .then((data)=>{
        res.status(200).send(data.toJSON())
    })
})
.catch((error)=>{console.log(error)})    
}

module.exports = {sendCapital:sendCapital}