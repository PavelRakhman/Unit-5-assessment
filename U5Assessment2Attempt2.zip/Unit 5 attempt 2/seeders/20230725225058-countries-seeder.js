'use strict';
let allCountries = require('../dataArrays/countryList')
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    for (let i=0; i< allCountries.length; i++)
    {
      await queryInterface.bulkInsert('countries', [{
        name: allCountries[i],
        createdAt: new Date(),
        updatedAt: new Date()
      }]);
    }
    
  },

  async down (queryInterface, Sequelize) {
    for ( let i=0; i< allCountries.length; i++)
    {
      return queryInterface.bulkDelete('countries', [{
        name: allCountries[i],
        createdAt: new Date(),
        updatedAt: new Date()
      }]);
    }  
    
  }
};
