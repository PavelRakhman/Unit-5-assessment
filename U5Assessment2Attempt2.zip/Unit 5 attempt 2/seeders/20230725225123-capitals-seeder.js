'use strict';
let allCapitals = require('../dataArrays/capitalList')
function randomRating()
{
  return (Math.floor(Math.random()*5)+1)
}

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  
  async up (queryInterface, Sequelize) {
  for (let i=0; i<allCapitals.length; i++)
  {
    await queryInterface.bulkInsert('capitals',
    [
      {
        name: allCapitals[i],
        rating: randomRating(),
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ]);
  }
  },

  async down (queryInterface, Sequelize) {
    for (let i=0; i<allCapitals.length; i++)
    {
      await queryInterface.bulkDelete('capitals',
      [
        {
          name: allCapitals[i],
          rating: randomRating(),
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ]);
    }  
  }
};
