const express = require("express")
const entryCtrl = require("../controllers/entryCtrl")
const router = express.Router()
router.post("/new", entryCtrl.addEntry)
router.get("/get", entryCtrl.getAllEntries)
module.exports = router