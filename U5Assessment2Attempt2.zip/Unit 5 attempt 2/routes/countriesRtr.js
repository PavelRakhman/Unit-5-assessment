const express =   require("express")
const countriesCtrl = require("../controllers/countriesCtrl")
const router = express.Router()
router.get("/", countriesCtrl.sendAllCountries)
module.exports = router