const express = require("express")
const capitalCtrl = require("../controllers/capitalCtrl")
const router = express.Router()
router.get("/",capitalCtrl.sendCapital)
module.exports = router